<?php

use Prappo\WpEloquent\Application;

Application::bootWp();
