<?php return array('dependencies' => array(), 'version' => '5e309f26cceac88b1e8d');
