=== WordPress Plugin Boilerplate ===
Requires at least: 5.9
Tested up to: 6.6
Stable tag: 1.0.0
Requires PHP: 7.2
License: GPLv2 or later

== Description ==

WordPress Plugin Boilerplate utilizing modern web technologies and tools such as React, TypeScript, SASS, Tailwind CSS, Shadcn UI, Vite, Storybook, HMR and more.
