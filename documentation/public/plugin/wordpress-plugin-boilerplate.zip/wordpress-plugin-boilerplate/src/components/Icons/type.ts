export interface ISvgIcon {
  className?: string;
  color?: string;
}
